package onlineshopping;

import java.util.Scanner;

public class Main {
    private static Shop shop = new Shop();
    private static Cart cart = new Cart();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Welcome to the Simple Online Shop");
        boolean running = true;
        while (running) {
            printMenu();
            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1" -> shop.showProducts();
                case "2" -> viewProductDetails();
                case "3" -> addToCart();
                case "4" -> cart.showCart();
                case "5" -> removeFromCart();
                case "6" -> checkout();
                case "0" -> { running = false; System.out.println("Goodbye!"); }
                default -> System.out.println("Invalid choice — try again.");
            }
        }
        scanner.close();
    }

    private static void printMenu() {
        System.out.println("\nMenu:");
        System.out.println("1. List products");
        System.out.println("2. View product details");
        System.out.println("3. Add product to cart");
        System.out.println("4. View cart");
        System.out.println("5. Remove product from cart");
        System.out.println("6. Checkout");
        System.out.println("0. Exit");
        System.out.print("Choose an option: ");
    }

    private static void viewProductDetails() {
        System.out.print("Enter product id: ");
        int id = Integer.parseInt(scanner.nextLine());
        Product p = shop.findById(id);
        if (p == null) System.out.println("Product not found.");
        else {
            System.out.println("Product details:");
            System.out.println("ID: " + p.getId());
            System.out.println("Name: " + p.getName());
            System.out.println("Price: ₹" + p.getPrice());
            System.out.println("Description: " + p.getDescription());
        }
    }

    private static void addToCart() {
        try {
            System.out.print("Enter product id to add: ");
            int id = Integer.parseInt(scanner.nextLine());
            Product p = shop.findById(id);
            if (p == null) { System.out.println("Product not found."); return; }
            System.out.print("Enter quantity: ");
            int qty = Integer.parseInt(scanner.nextLine());
            if (qty <= 0) { System.out.println("Quantity must be > 0"); return; }
            cart.addProduct(p, qty);
            System.out.printf("Added %d x %s to cart.\n", qty, p.getName());
        } catch (NumberFormatException e) {
            System.out.println("Invalid input — please enter numbers.");
        }
    }

    private static void removeFromCart() {
        System.out.print("Enter product id to remove from cart: ");
        try {
            int id = Integer.parseInt(scanner.nextLine());
            cart.removeProductById(id);
            System.out.println("If it existed, product removed from cart.");
        } catch (NumberFormatException e) {
            System.out.println("Invalid input.");
        }
    }

    private static void checkout() {
        if (cart.isEmpty()) {
            System.out.println("Cart is empty — nothing to checkout.");
            return;
        }
        cart.showCart();
        System.out.print("Proceed to checkout? (y/n): ");
        String ans = scanner.nextLine().trim().toLowerCase();
        if (ans.equals("y") || ans.equals("yes")) {
            double total = cart.getTotal();
            // simple billing: no taxes/discounts — you can add them
            System.out.printf("Order placed. Total amount: ₹%.2f\n", total);
            cart.clear();
        } else {
            System.out.println("Checkout cancelled.");
        }
    }
}
