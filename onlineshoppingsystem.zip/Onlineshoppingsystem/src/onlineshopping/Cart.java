package onlineshopping;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Cart {
    private List<CartItem> items = new ArrayList<>();

    public void addProduct(Product p, int qty) {
        for (CartItem it : items) {
            if (it.getProduct().getId() == p.getId()) {
                it.setQuantity(it.getQuantity() + qty);
                return;
            }
        }
        items.add(new CartItem(p, qty));
    }

    public void removeProductById(int productId) {
        Iterator<CartItem> it = items.iterator();
        while (it.hasNext()) {
            CartItem item = it.next();
            if (item.getProduct().getId() == productId) {
                it.remove();
                return;
            }
        }
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }

    public double getTotal() {
        double sum = 0;
        for (CartItem it : items) sum += it.getTotalPrice();
        return sum;
    }

    public void clear() { items.clear(); }

    public void showCart() {
        if (items.isEmpty()) {
            System.out.println("Your cart is empty.");
            return;
        }
        System.out.println("Items in cart:");
        for (CartItem it : items) {
            System.out.println(" - " + it);
        }
        System.out.printf("Cart total: ₹%.2f\n", getTotal());
    }
}
