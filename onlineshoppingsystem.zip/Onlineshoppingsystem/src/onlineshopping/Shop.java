package onlineshopping;

import java.util.ArrayList;
import java.util.List;

public class Shop {
    private List<Product> catalog = new ArrayList<>();

    public Shop() {
        loadSampleProducts();
    }

    private void loadSampleProducts() {
        // sample items (you can replace/add)
        catalog.add(new Product(1, "Notebook", "200-page ruled notebook", 49.00));
        catalog.add(new Product(2, "Pen (Blue)", "Gel ink pen", 15.50));
        catalog.add(new Product(3, "Water Bottle", "750ml steel bottle", 399.00));
        catalog.add(new Product(4, "Backpack", "School backpack, 20L", 899.00));
        catalog.add(new Product(5, "Headphones", "On-ear headphones", 1299.00));
    }

    public List<Product> getCatalog() { return catalog; }

    public Product findById(int id) {
        for (Product p : catalog) if (p.getId() == id) return p;
        return null;
    }

    public void showProducts() {
        System.out.println("Available products:");
        for (Product p : catalog) {
            System.out.println(p);
        }
    }
}
